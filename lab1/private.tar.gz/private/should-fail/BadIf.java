class BadIf {
    public static void main(String[] a){
        System.out.println(new B().run());
    }
}

class B {
    public int run() {
    	int a;
	else {
	    a = 4;	
	}
	return a;
    }
}
